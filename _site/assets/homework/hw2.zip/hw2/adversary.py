
def adversary(call, encrypted_message=None):
    """Adversary function."""
        # TODO: Any starter code
    if call == 1:
        # First call: Adversary specifies two messages
        # TODO
        return
    elif call == 2:
        # Second call: Adversary guesses which message was encrypted
        # TODO
        return
