from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def dec(key, ciphertext):
    """Decrypt the message using the given encryption scheme."""
    # TODO
    return 
